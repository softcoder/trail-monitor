<div class="vstm_about">
	<h3>About Trail Monitor</h3>
	<hr>
	<p>Developed by <a href="https://vsoft.solutions" target="_blank">VSoft Solutions</a></p>
	<p>Bugs, feature requests? Please visit our website and send us an email</p>
	<p>
		<a href="https://hiking.princegeorge.tech/software/trail-monitor-wordpress-plugin/" class="button-primary" target="_blank">Support this Plugin</a>
		<br>
	</p>
</div>